import { GlobalState } from "@/store/types";

const state: Partial<GlobalState> = {};
